package com.medibank.app;

/**
 * Commands from Coach
 * @author nareshm
 */
public enum Commands {
    L, R, M
}