package com.medibank.app;

/**
 * Represents the four directions of the soccer pitch.
 * @author nareshm
 */
public enum Directions {
    N, E, W, S
}
